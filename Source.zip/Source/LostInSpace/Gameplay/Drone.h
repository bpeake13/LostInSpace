// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Gameplay/BaseEnemyPawn.h"
#include "Drone.generated.h"

/**
 * 
 */
UCLASS()
class ADrone : public ABaseEnemyPawn
{
	GENERATED_BODY()
public:
	ADrone();
	
	
};
